//Homework02, DisplayActivity.java, Brady Ennis
package com.example.homework02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {
    public static final int REQ_CODE = 100;

    TextView displayName, displayEmail, displayDept, displayMood;
    ImageView editName, editEmail, editDept, editMood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        if(getIntent() != null && getIntent().getExtras() != null) {

            displayName = findViewById(R.id.personNameView);
            displayEmail = findViewById(R.id.personEmailView);
            displayDept = findViewById(R.id.personDeptView);
            displayMood = findViewById(R.id.personMoodView);

            Student student = (Student) getIntent().getExtras().getSerializable(MainActivity.STUDENT_KEY);

            if (student != null) {
                displayName.setText(student.name);
                displayEmail.setText(student.email);
                displayDept.setText(student.department);
                displayMood.setText(student.mood + "% Positive");
            }

            editName = findViewById(R.id.editNameButton);
            editEmail = findViewById(R.id.editEmailButton);
            editDept = findViewById(R.id.editDepartmentButton);
            editMood = findViewById(R.id.editMoodButton);

            editName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intentName = new Intent(DisplayActivity.this, EditActivity.class);
                    startActivityForResult(intentName, REQ_CODE);
                }
            });
            editEmail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intentEmail = new Intent(DisplayActivity.this, EditActivity.class);
                    startActivityForResult(intentEmail, REQ_CODE);
                }
            });
            editDept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intentDept = new Intent(DisplayActivity.this, EditActivity.class);
                    startActivityForResult(intentDept, REQ_CODE);
                }
            });
            editMood.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intentMood = new Intent(DisplayActivity.this, EditActivity.class);
                    startActivityForResult(intentMood, REQ_CODE);
                }
            });
        }
    }
}