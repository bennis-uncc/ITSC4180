package com.example.homework02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

public class EditActivity extends AppCompatActivity {

    TextView newName, newEmail;
    RadioGroup newRG;
    SeekBar newSB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);


        newName = findViewById(R.id.editPersonName);
        newEmail = findViewById(R.id.editPersonEmail);
        newRG = findViewById(R.id.editDepartmentButtons);
        newSB = findViewById(R.id.editMoodBar);

        findViewById(R.id.saveEditButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String editedName = newName.getText().toString();
                String editedEmail = newEmail.getText().toString();
                newRG = findViewById(R.id.editDepartmentButtons);
                int newRB = newRG.getCheckedRadioButtonId();
                RadioButton editedRadioButton = findViewById(newRB);
                newSB = findViewById(R.id.editMoodBar);
                int newMood = newSB.getProgress();

                finish();
            }
        });
    }
}