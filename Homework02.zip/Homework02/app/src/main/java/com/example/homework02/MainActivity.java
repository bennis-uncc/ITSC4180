package com.example.homework02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    static String NAME_KEY = "NAME";
    static String EMAIL_KEY = "EMAIL";
    static String DEPT_KEY = "DEPARTMENT";
    static String ACCT_KEY = "ACCOUNT";
    static String MOOD_KEY = "MOOD";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*
                    create intent here
                 */
            }
        });

    }
}
