//Homework02, MainActivity.java, Brady Ennis
package com.example.homework02;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    static String STUDENT_KEY = "STUDENT";
    TextView name, email;
    RadioGroup rg;
    SeekBar sb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DisplayActivity.class);

                name = findViewById(R.id.personName);
                email = findViewById(R.id.personEmail);
                rg = findViewById(R.id.departmentButtons);
                int rb = rg.getCheckedRadioButtonId();
                RadioButton radioButton = findViewById(rb);
                sb = findViewById(R.id.moodBar);

                String nameString = name.getText().toString();
                String emailString = email.getText().toString();
                String deptString = radioButton.getText().toString();
                int mood = sb.getProgress();

                Student student = new Student(nameString, emailString, deptString, mood);
                intent.putExtra(STUDENT_KEY, student);

                startActivity(intent);
            }
        });

    }
}
