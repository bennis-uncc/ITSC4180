package edu.uncc.hw04;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.Collection;

import edu.uncc.hw04.utils.Data;

 public class AppCategoriesActivity extends AppCompatActivity {
    public final String TAG = "demo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_categories);
        //Data.apps.keySet(); //to get the keys which are the app categories.
        Log.d(TAG, "onCreate: " + Data.apps.get("Top Free Apps"));

        ListView categoryList = findViewById(R.id.categoryList);
        Collection<String> values = Data.apps.keySet();
        final String[] appCats = values.toArray(new String[values.size()]);

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                android.R.id.text1, appCats);
        categoryList.setAdapter(categoryAdapter);

        categoryList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(AppCategoriesActivity.this, AppsListActivity.class);
                intent.putExtra("AppPosition", position);
                intent.putExtra("AppID", id);
                startActivity(intent);
            }
        });

    }
}