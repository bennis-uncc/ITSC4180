package edu.uncc.hw04;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collection;

import edu.uncc.hw04.utils.App;
import edu.uncc.hw04.utils.Data;

public class AppsListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apps_list);

        ListView appList = findViewById(R.id.appList);
        Intent intent = getIntent();
        int positionValue = intent.getIntExtra("AppPosition", 0);
        long idValue = intent.getLongExtra("AppID", 0);

        Collection<String> values = Data.apps.keySet();
        final String[] appCats = values.toArray(new String[values.size()]);
        setTitle(appCats[positionValue]);

        
    }
}
